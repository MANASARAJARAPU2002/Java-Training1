package Dailyexercises.Animals;

public interface Pet {
	//String (getName);
	void setName(String name);
	void play();
	String getName();
	

}
