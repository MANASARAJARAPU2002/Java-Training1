package Dailyexercies.Areas;

public interface CalculateArea {
	double calculateArea();
}

