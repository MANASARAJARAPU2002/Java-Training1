
package Dailyexercies.Areas;

public interface CalculateVolume {
	double calculateVolume();
}
